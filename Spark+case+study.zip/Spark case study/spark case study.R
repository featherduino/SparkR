#code for 2015 data with results in comments
# load SparkR

library(SparkR)


# initiating the spark session

sparkR.session(master='local')


Parking_2015 <- read.df("s3://databucket102/Parking_Violations_Issued_-_Fiscal_Year_2015.csv",
   
                     
                        source = "csv", inferSchema = "true", header = "true")


head(Parking_2015)

nrow(Parking_2015)

#11,809,233 rows
ncol(Parking_2015)
#51 columns

createOrReplaceTempView(Parking_2015, "Park_2015")

#Examine the data

#1) Find total number of tickets for each year.
# 10,951,256 distinct summons/tickets

unique_tickets <- SparkR::sql("SELECT count(distinct `Summons Number`) FROM Park_2015")

head(unique_tickets)

# 2) Find out how many unique states the cars which got parking tickets came from.
# 69 unique registration states

unique_states <- SparkR::sql("SELECT count(distinct `Registration State`) FROM Park_2015")

head(unique_states)

#Removing the duplicate rows
#10,951,257 rows
Parking_2015_distinct<-dropDuplicates(Parking_2015)

nrow(Parking_2015_distinct)

createOrReplaceTempView(Parking_2015_distinct, "Park_2015_distinct")


#3) Some parking tickets don�t have addresses on them, which is cause for concern. Find out how many such tickets there are.

#1,807,864 missing addresses i.e. either house number or street name missing in the deduplicated dataset

blank_address <- SparkR::sql("SELECT count(*) FROM Park_2015_distinct WHERE isNull(`House Number`) OR isNull(`Street Name`)")


head(blank_address)

#Aggregation Tasks

#1) How often does each violation code occur? (frequency of violation codes - find the top 5)
#Violation Code  	frequency
#         21		1501614
#          38         	1324586
#         14		924627
#          36 		761571
#          37		746278     		

viol_code_counts <- summarize(groupBy(Parking_2015_distinct, Parking_2015_distinct$`Violation Code`),
 count = n(Parking_2015_distinct$`Violation Code`))
head(arrange(viol_code_counts, desc(viol_code_counts$count)))


#2) How often does each vehicle body type get a parking ticket? How about the vehicle make? (find the top 5 for both)
#Vehicle Body Type  	frequency
#         SUBN 	3451963
#        4DSD 	3102510 
#         VAN 	1605228
#       DELV  	840442
#          SDN  	453992
body_type_counts <- summarize(groupBy(Parking_2015_distinct, Parking_2015_distinct$`Vehicle Body Type`),
 count = n(Parking_2015_distinct$`Vehicle Body Type`))

head(arrange(body_type_counts, desc(body_type_counts$count)))

#Vehicle Make  	frequency
#  FORD 		1417303       
#  TOYOT 		1123523   
#  HONDA 	1018049
#  NISSA  		837569
# CHEVR  	836389

vehicle_make_counts <- summarize(groupBy(Parking_2015_distinct, Parking_2015_distinct$`Vehicle Make`),
 count = n(Parking_2015_distinct$`Vehicle Make`))

head(arrange(vehicle_make_counts, desc(vehicle_make_counts$count)))

#3) A precinct is a police station that has a certain zone of the city under its command. Find the (5 highest) frequencies of:
# a)Violating Precincts (this is the precinct of the zone where the violation occurred)
#Violating Precincts	Freq
# 	0 	1633006 (assuming this to be the missing )
# 	19  	559716
# 	18  	400887
# 	14  	384596
#	1  	307808
#	114  	300557
viol_prec_counts <- summarize(groupBy(Parking_2015_distinct, Parking_2015_distinct$`Violation Precinct`),
 count = n(Parking_2015_distinct$`Violation Precinct`))

head(arrange(viol_prec_counts, desc(viol_prec_counts$count)))

#b)Issuing Precincts (this is the precinct that issued the ticket)
#Issuer Precincts	Freq
# 	0 	1834343(assuming this to be the missing )
# 	19  	544946
# 	18  	391501
# 	14  	384596
#	 1  	298594
#	114  	295601
issue_prec_counts <- summarize(groupBy(Parking_2015_distinct, Parking_2015_distinct$`Issuer Precinct`),
 count = n(Parking_2015_distinct$`Issuer Precinct`))

head(arrange(issue_prec_counts, desc(issue_prec_counts$count)))

#4)Find the violation code frequency across 3 precincts which have issued the most number of tickets - 
#assuming '0' as missing, top three issuer Precinct are 19,18 and 14

Parking_2015_distinct_top_prec<- filter(Parking_2015_distinct, Parking_2015_distinct$`Issuer Precinct` == 19 | Parking_2015_distinct$`Issuer Precinct`==18 | Parking_2015_distinct$`Issuer Precinct`==14 )

freq_4 <- summarize(groupBy(Parking_2015_distinct_top_prec, Parking_2015_distinct_top_prec$`Issuer Precinct`,Parking_2015_distinct_top_prec$`Violation Code`),
 count = n(Parking_2015_distinct_top_prec$`Issuer Precinct`))

head(arrange(freq_4 , desc(freq_4 $count)),num=20)

##  Issuer Precinct Violation Code freq
#1               18             14 	121004
#2               19             38  	90437
#3               14             69  	80368
#4               19             37  	79738
#5               14             14  	77269
#6               19             14  	60589
#7               18             69  	57218
#8               19             21  	56416
#9               19             16  	56318
#10              19             46  	44082
#11              14             31  	41049
#12              19             20 	 32436
#13              18             31  	30447
#14              18             47  	9124
#15              14             42  	28114
#16              19             40  	27920
#17              14             47  	27229
#18              18             42  	19820
#19              18             38  	18763
#20              19             71  	16957

#Precinct '18' has issued highest number of violation code '14'
#Precinct '19' has issued highest number of violation code '38'
#Precinct '14' has issued highest number of violation code '69'

freq_4a <- summarize(groupBy(Parking_2015_distinct_top_prec, Parking_2015_distinct_top_prec$`Violation Code`),
 count = n(Parking_2015_distinct_top_prec$`Violation Code`))


head(arrange(freq_4a , desc(freq_4a $count)))
##    Violation code      freq
#1              14 	258862
#2             69 	142391
#3             38 	116085
#4             37  	91840
#5             31  	73784
#6             46  	71104

#across three precincts, violation code '14 ' was issued most number of times

#do these precinct zones have an exceptionally high frequency of certain violation codes? Are these codes common across precincts?
#Exceptionally high frequency can be seen for violation codes 14 followed by 69 and 38.   However, only code '14' has shown consistently higher number across the top three issuer precincts.

#5)You�d want to find out the properties of parking violations across different times of the day:
#The Violation Time field is specified in a strange format. Find a way to make this into a time attribute that you can use to divide into groups.
#Find a way to deal with missing values, if any.
blank_violation_time<- SparkR::sql("SELECT count(*) FROM Park_2015_distinct WHERE isNull(`Violation Time`) ")


head(blank_violation_time)

#there are only 1562 rows with missing violation time. Since the number is low, we are ignoring the same
##Substringing the hour part 

violation_2015_time <- withColumn(Parking_2015_distinct, "hour", substr(Parking_2015_distinct$`Violation Time`, 1, 2))
#substeing the clock am or pm 
violation_2015_time <- withColumn(violation_2015_time, "clock", substr(violation_2015_time$`Violation Time`, 6, 6))
#Converting to integer the hour 
violation_2015_time <- withColumn(violation_2015_time, "hour", cast(violation_2015_time$hour, "int"))

createOrReplaceTempView(violation_2015_time, "violation_2015_time")

#Divide 24 hours into 6 equal discrete bins of time. The intervals you choose are at your discretion. For each of these groups, 
#find the 3 most commonly occurring violations
#00-03 AM
violation_2015_time_1 <- SparkR::sql("SELECT * from violation_2015_time WHERE  hour BETWEEN 00 AND 03 AND clock == 'A'")
violation_frequency_1 <- summarize(groupBy(violation_2015_time_1,violation_2015_time_1$`Violation Code`),count = n(violation_2015_time_1$`Violation Code`))
head(arrange(violation_frequency_1, desc(violation_frequency_1$count)),n=5)
# Violation Code 	count
#1             21 	63574
#2             40 	36490
#3             78 	34842
#4             14 	26545
#5             85 	24865

#21 violation code occurs the max
##04-07AM
violation_2015_time_2 <- SparkR::sql("SELECT * from violation_2015_time WHERE  hour BETWEEN 04 AND 07 AND clock == 'A'")
violation_frequency_2 <- summarize(groupBy(violation_2015_time_2, violation_2015_time_2$`Violation Code`),count = n(violation_2015_time_2$`Violation Code`))
head(arrange(violation_frequency_2, desc(violation_frequency_2$count)),n=5)

#Violation Code  	count
#1             14 	134458
#2             21 	106858
#3             40 	91344
#4             20  	81103
#5              36  	56550

#4-7 violation code 14 occurs the most

#08-11 AM
violation_2015_time_3 <- SparkR::sql("SELECT * from violation_2015_time WHERE  hour BETWEEN 08 AND 11 AND clock == 'A'")
violation_frequency_3 <- summarize(groupBy(violation_2015_time_3, violation_2015_time_3$`Violation Code`),count = n(violation_2015_time_3$`Violation Code`))
head(arrange(violation_frequency_3, desc(violation_frequency_3$count)),n=5)
#Violation Code   	count
#1             21 	1192163
#2             38  	449070
#3             36 	360365
#4             14  	297711
#5             46  	210978
#violation code 21 occurs the most

#12-3 PM
violation_2015_time_4_a <- SparkR::sql("SELECT * from violation_2015_time WHERE hour == 12 AND clock == 'P'")
violation_2015_time_4_b <- SparkR::sql("SELECT * from violation_2015_time WHERE hour BETWEEN 01 AND 03 AND clock == 'P'")
violation_2015_time_4 <- unionAll(violation_2015_time_4_a, violation_2015_time_4_b)
violation_frequency_4 <- summarize(groupBy(violation_2015_time_4, violation_2015_time_4$`Violation Code`),count = n(violation_2015_time_4$`Violation Code`))

head(arrange(violation_frequency_4, desc(violation_frequency_4$count)),n=5)

#1             38 	568269
#2             37 	417610
#3             36 	323524
#4             14 	267567
#5             20 	209791

#Violation code 38 very prominent between 12-3 pm
#04-07 PM
violation_2015_time_5 <- SparkR::sql("SELECT * from violation_2015_time WHERE  hour BETWEEN 04 AND 07 AND clock == 'P'")

violation_frequency_5 <- summarize(groupBy(violation_2015_time_5, violation_2015_time_5$`Violation Code`),count = n(violation_2015_time_5$`Violation Code`))

head(arrange(violation_frequency_5, desc(violation_frequency_5$count)),n=5)

#1             38 	241327
#2             37 	175802
#3             7 	168888
#4              14 	148538
#5             5  	89709

# Violation code 38 is  highest

#08-11 PM
violation_2015_time_6 <- SparkR::sql("SELECT * from violation_2015_time WHERE  hour BETWEEN 08 AND 11 AND clock == 'P'")

violation_frequency_6 <- summarize(groupBy(violation_2015_time_6, violation_2015_time_6$`Violation Code`),count = n(violation_2015_time_6$`Violation Code`))

head(arrange(violation_frequency_6, desc(violation_frequency_6$count)),n=5)

#Violation Code 	count
#1              7 	81981
#2             38 	62418
#3             14 	45821
#4             40 	44891
#5             20 	31231

#Violation code 7 is highest between 8 -11

#Now, try another direction. For the 3 most commonly occurring violation codes, find the most common times of day (in terms of the bins from the previous part)
#           7  # late evening 8 pm onwards
#           38  # afternoon and evening from 12 pm to 8 pm
#           21  # mid morning 8 am to 12 noon
#           14 # morning 4am to 8 am
#          21 # early morning 12 midnight to 4 pm

#21,38 are the most common violation code 

#6)Let�??s try and find some seasonality in this data
#First, divide the year into some number of seasons, and find frequencies of tickets for each season.
#Then, find the 3 most common violations for each of these season

violation_2015_month <- withColumn(Parking_2015_distinct, "month", substr(Parking_2015_distinct$`Issue Date`, 1, 2))
violation_2015_month <- withColumn(violation_2015_month, "month", cast(violation_2015_month$month, "int"))

createOrReplaceTempView(violation_2015_month,"violation_2015_month")

#Month 1 -3
violation_2015_season_1 <- SparkR::sql("SELECT * from violation_2015_month WHERE  month BETWEEN 1 AND 3")
violation_frequency_season_1 <- summarize(groupBy(violation_2015_season_1, violation_2015_season_1$`Violation Code`),count = n(violation_2015_season_1$`Violation Code`))
collect(agg(violation_frequency_season_1, sum(violation_frequency_season_1$count)))

# Answer Sum(count)
#1    2475936

head(arrange(violation_frequency_season_1, desc(violation_frequency_season_1$count)),n=5)

#Answer 
#1             38 	336762
#2             21 	281600
#3             14 	220029
#4             37 	177529
#5             36 	168436

#38 Violation code is highest 


#Month 4-6
violation_2015_season_2 <- SparkR::sql("SELECT * from violation_2015_month WHERE  month BETWEEN 4 AND 6")
violation_frequency_season_2 <- summarize(groupBy(violation_2015_season_2, violation_2015_season_2$`Violation Code`),count = n(violation_2015_season_2$`Violation Code`))

collect(agg(violation_frequency_season_2, sum(violation_frequency_season_2$count)))

## Answers                 sum(count)
# 1    		3250418

head(arrange(violation_frequency_season_2, desc(violation_frequency_season_2$count)),n=5)

#Answers 
#Violation 	Code  count
#1             21 	471580
#2             38 	346719
#3             14 	262595
#4             36 	252286
#5             7 	242871

#Months 7 - 9
violation_2015_season_3 <- SparkR::sql("SELECT * from violation_2015_month WHERE  month BETWEEN 7 AND 9")
violation_frequency_season_3 <- summarize(groupBy(violation_2015_season_3, violation_2015_season_3$`Violation Code`),count = n(violation_2015_season_3$`Violation Code`))

collect(agg(violation_frequency_season_3, sum(violation_frequency_season_3$count)))

## Answer 2789425

head(arrange(violation_frequency_season_3, desc(violation_frequency_season_3$count)),n=5)
#1             21 	397871
#2             38 	348466
#3             14 	234606
#4             37 	199497
#5             7 	175814

#Months 10-12
violation_2015_season_4 <- SparkR::sql("SELECT * from violation_2015_month WHERE  month BETWEEN 10 AND 12")
violation_frequency_season_4 <- summarize(groupBy(violation_2015_season_4, violation_2015_season_4$`Violation Code`),count = n(violation_2015_season_4$`Violation Code`))

collect(agg(violation_frequency_season_4, sum(violation_frequency_season_4$count)))

## Answer  sum(count)
#1    2435478

head(arrange(violation_frequency_season_4, desc(violation_frequency_season_4$count)),n=5)

#Violation Code  count
#1             21 	350563
#2             38 	292639
#3             14	 207397
#4             36	 175899
#5             37 	162875

####################################################################
# code for 2016 data
# 1. Initialize spark session
# load SparkR
library(SparkR)

# initialise the spark session
sparkR.session(master='local')

# 2. Create a Spark DataFrame and examine structure
# reading a CSV file from S3 bucket
Parking_2016 <- read.df("s3://akhileshb1/case_study/Parking_Violations_Issued_-_Fiscal_Year_2016.csv", source = "csv",
                        header = TRUE, inferSchema = TRUE)

head(Parking_2016)

#10,626,899 rows
ncol(Parking_2016)
#51 columns

createOrReplaceTempView(Parking_2016, "Park_2016")

#Examine the data

#1) Find total number of tickets for each year.
# 10,626,899 distinct summons/tickets

unique_tickets <- SparkR::sql("SELECT count(distinct `Summons Number`) FROM Park_2016")

head(unique_tickets)

# 2) Find out how many unique states the cars which got parking tickets came from.
# 68 unique registration states

unique_states <- SparkR::sql("SELECT count(distinct `Registration State`) FROM Park_2016")

head(unique_states)

#Removing the duplicate rows
#10,626,899 rows
Parking_2016_distinct<-dropDuplicates(Parking_2016)

nrow(Parking_2016_distinct)

createOrReplaceTempView(Parking_2016_distinct, "Park_2016_distinct")


#3) Some parking tickets don�t have addresses on them, which is cause for concern. Find out how many such tickets there are.

#2,035,232 missing addresses i.e. either house number or street name missing in the deduplicated dataset Violation Post Code

blank_address <- SparkR::sql("SELECT count(*) FROM Park_2016_distinct WHERE isNull(`House Number`) OR isNull(`Street Name`) OR isNull(`Violation Post Code`)")


head(blank_address)

#Aggregation Tasks

#1) How often does each violation code occur? (frequency of violation codes - find the top 5)
#Violation Code  	frequency
#             21 	1531587
#             36 	1253512
#             38 	1143696
#             14  	875614
#             37  	686610


viol_code_counts <- summarize(groupBy(Parking_2016_distinct, Parking_2016_distinct$`Violation Code`),
                              count = n(Parking_2016_distinct$`Violation Code`))
head(arrange(viol_code_counts, desc(viol_code_counts$count)))


#2) How often does each vehicle body type get a parking ticket? How about the vehicle make? (find the top 5 for both)
#Vehicle Body Type  	frequency
#              SUBN 	3466037
#              4DSD 	2992107
#               VAN 	1518303
#              DELV  	755282
#               SDN  	424043

body_type_counts <- summarize(groupBy(Parking_2016_distinct, Parking_2016_distinct$`Vehicle Body Type`),
                              count = n(Parking_2016_distinct$`Vehicle Body Type`))

head(arrange(body_type_counts, desc(body_type_counts$count)))

#Vehicle Make  	frequency
#         FORD 	1324774
#        TOYOT 	1154790
#        HONDA 	1014074
#        NISSA  	834833
#        CHEVR  	759663


vehicle_make_counts <- summarize(groupBy(Parking_2016_distinct, Parking_2016_distinct$`Vehicle Make`),
                                 count = n(Parking_2016_distinct$`Vehicle Make`))

head(arrange(vehicle_make_counts, desc(vehicle_make_counts$count)))

#3) A precinct is a police station that has a certain zone of the city under its command. Find the (5 highest) frequencies of:
# a)Violating Precincts (this is the precinct of the zone where the violation occurred)
#Violating Precincts	Freq
# 	0 	1868655 (assuming this to be the missing )
# 	19  	554465
# 	18  	331704
# 	14  	324467
#	   1  	303850
#	 114  	291336
viol_prec_counts <- summarize(groupBy(Parking_2016_distinct, Parking_2016_distinct$`Violation Precinct`),
                              count = n(Parking_2016_distinct$`Violation Precinct`))

head(arrange(viol_prec_counts, desc(viol_prec_counts$count)))


#b)Issuing Precincts (this is the precinct that issued the ticket)
#Issuer Precincts	Freq
# 	0  	2140274	(assuming this to be the missing )
# 	19  	540569	
# 	18  	323132 	
# 	14  	315311	
#	 1  	295013
#	114  	286924
issue_prec_counts <- summarize(groupBy(Parking_2016_distinct, Parking_2016_distinct$`Issuer Precinct`),
                               count = n(Parking_2016_distinct$`Issuer Precinct`))

head(arrange(issue_prec_counts, desc(issue_prec_counts$count)))

#4)Find the violation code frequency across 3 precincts which have issued the most number of tickets - 
#assuming '0' as missing, top three issuer Precinct are 19,18 and 14

Parking_2016_distinct_top_prec<- filter(Parking_2016_distinct, Parking_2016_distinct$`Issuer Precinct` == 19 | Parking_2016_distinct$`Issuer Precinct`==18 | Parking_2016_distinct$`Issuer Precinct`==14 )

freq_4 <- summarize(groupBy(Parking_2016_distinct_top_prec, Parking_2016_distinct_top_prec$`Issuer Precinct`,Parking_2016_distinct_top_prec$`Violation Code`),
                    count = n(Parking_2016_distinct_top_prec$`Issuer Precinct`))

head(arrange(freq_4 , desc(freq_4 $count)),num=20)

##  Issuer Precinct Violation Code freq
#1               18             14 	99857
#2               19             38 	77183
#3               19             37 	75641
#4               19             46 	73016
#5               14             69 	67932
#6               14             14 	62426
#7               19             14 	61742
#8               19             21 	58719
#9               19             16 	52354
#10              18             69 	47881
#11              14             31 	35711
#12              19             20 	29280
#13              14             47 	24450
#14              18             47 	24009
#15              14             42 	23662
#16              18             31 	22809
#17              19             40 	21903
#18              18             42 	17678
#19              19             71 	15190
#20              18             46 	14674
#Precinct '18' has issued highest number of violation code '14'
#Precinct '19' has issued highest number of violation code '38'
#Precinct '14' has issued highest number of violation code '69'

freq_4a <- summarize(groupBy(Parking_2016_distinct_top_prec, Parking_2016_distinct_top_prec$`Violation Code`),
                     count = n(Parking_2016_distinct_top_prec$`Violation Code`))


head(arrange(freq_4a , desc(freq_4a $count)))
##    Violation code      freq
#1             14 	224025
#2             69 	119857
#3             46  	98097
#4             38  	97168
#5             37  	86040
#6             21  	64621


#across three precincts, violation code '14 ' was issued most number of times

#do these precinct zones have an exceptionally high frequency of certain violation codes? Are these codes common across precincts?
#Exceptionally high frequency can be seen for violation codes 14 followed by 69 and 46.   However, only code '14' has shown consistently higher number across the top three issuer precincts.

#5)You�d want to find out the properties of parking violations across different times of the day:
#The Violation Time field is specified in a strange format. Find a way to make this into a time attribute that you can use to divide into groups.
#Find a way to deal with missing values, if any.

##Substringing the hour part 

violation_2016_time <- withColumn(Parking_2016_distinct, "hour", substr(Parking_2016_distinct$`Violation Time`, 1, 2))
#substeing the clock am or pm 
violation_2016_time <- withColumn(violation_2016_time, "clock", substr(violation_2016_time$`Violation Time`, 6, 6))
#Converting to integer the hour 
violation_2016_time <- withColumn(violation_2016_time, "hour", cast(violation_2016_time$hour, "int"))

createOrReplaceTempView(violation_2016_time, "violation_2016_time")

#Divide 24 hours into 6 equal discrete bins of time. The intervals you choose are at your discretion. For each of these groups, 
#find the 3 most commonly occurring violations
#00-03 AM
violation_2016_time_1 <- SparkR::sql("SELECT * from violation_2016_time WHERE  hour BETWEEN 00 AND 03 AND clock == 'A'")
violation_frequency_1 <- summarize(groupBy(violation_2016_time_1,violation_2016_time_1$`Violation Code`),count = n(violation_2016_time_1$`Violation Code`))
head(arrange(violation_frequency_1, desc(violation_frequency_1$count)),n=5)
# Violation Code 	count
#1             21 	67798
#2             40 	37261
#3             78 	29473
#4             14 	28608
#5             20 	20672

#21 violation code occurs the max
##04-07AM
violation_2016_time_2 <- SparkR::sql("SELECT * from violation_2016_time WHERE  hour BETWEEN 04 AND 07 AND clock == 'A'")
violation_frequency_2 <- summarize(groupBy(violation_2016_time_2, violation_2016_time_2$`Violation Code`),count = n(violation_2016_time_2$`Violation Code`))
head(arrange(violation_frequency_2, desc(violation_frequency_2$count)),n=5)

#Violation Code  	count
#1             14 	140111
#2             21 	114029
#3             40 	91692
#4             36  	79797
#5              20  	77831

#4-7 violation code 14 occurs the most

#08-11 AM
violation_2016_time_3 <- SparkR::sql("SELECT * from violation_2016_time WHERE  hour BETWEEN 08 AND 11 AND clock == 'A'")
violation_frequency_3 <- summarize(groupBy(violation_2016_time_3, violation_2016_time_3$`Violation Code`),count = n(violation_2016_time_3$`Violation Code`))
head(arrange(violation_frequency_3, desc(violation_frequency_3$count)),n=5)
#Violation Code   	count
#1	21 	1209243
#2             36  	586791
#3             38  	388099
#4             14  	276273
#5             46  	220535
#violation code 21 occurs the most

#12-3 PM
violation_2016_time_4_a <- SparkR::sql("SELECT * from violation_2016_time WHERE hour == 12 AND clock == 'P'")
violation_2016_time_4_b <- SparkR::sql("SELECT * from violation_2016_time WHERE hour BETWEEN 01 AND 03 AND clock == 'P'")
violation_2016_time_4 <- unionAll(violation_2016_time_4_a, violation_2016_time_4_b)
violation_frequency_4 <- summarize(groupBy(violation_2016_time_4, violation_2016_time_4$`Violation Code`),count = n(violation_2016_time_4$`Violation Code`))

head(arrange(violation_frequency_4, desc(violation_frequency_4$count)),n=5)

#1             36 	545717
#2             38 	488301
#3             37 	383357
#4             14 	247904
#5             20 	216615

#Violation code 36 very prominent between 12-3 pm
#04-07 PM
violation_2016_time_5 <- SparkR::sql("SELECT * from violation_2016_time WHERE  hour BETWEEN 04 AND 07 AND clock == 'P'")

violation_frequency_5 <- summarize(groupBy(violation_2016_time_5, violation_2016_time_5$`Violation Code`),count = n(violation_2016_time_5$`Violation Code`))

head(arrange(violation_frequency_5, desc(violation_frequency_5$count)),n=5)

#1             38 	211267
#2             37 	161655
#3             14 	134976
#4              7 	124617
#5             20  	82603

# Violation code 38  is  highest

#08-11 PM
violation_2016_time_6 <- SparkR::sql("SELECT * from violation_2016_time WHERE  hour BETWEEN 08 AND 11 AND clock == 'P'")

violation_frequency_6 <- summarize(groupBy(violation_2016_time_6, violation_2016_time_6$`Violation Code`),count = n(violation_2016_time_6$`Violation Code`))

head(arrange(violation_frequency_6, desc(violation_frequency_6$count)),n=5)

#Violation Code 	count
#1               7	 	60924
#2             38 	53174
#3             40 	44973
#4             14 		44227
#5             20 	31163

#Violation code 7  is highest between 8 -12 midnight

#Now, try another direction. For the 3 most commonly occurring violation codes, find the most common times of day (in terms of the bins from the previous part)
#           7  # late evening 8 pm to 12 midnight
#          38 # evening from 4pm to 8pm
#           36  # afternoon from 12 pm to 4 pm
#           21  # mid morning 8 am to 12 noon
#           14 # morning 4am to 8 am
#          21 # early morning 12 midnight to 4 pm

#21, 38 are the most common violation code 

#6)Let�??s try and find some seasonality in this data
#First, divide the year into some number of seasons, and find frequencies of tickets for each season.
#Then, find the 3 most common violations for each of these season

violation_2016_month <- withColumn(Parking_2016_distinct, "month", substr(Parking_2016_distinct$`Issue Date`, 1, 2))
violation_2016_month <- withColumn(violation_2016_month, "month", cast(violation_2016_month$month, "int"))

createOrReplaceTempView(violation_2016_month,"violation_2016_month")

#Month 1 -3
violation_2016_season_1 <- SparkR::sql("SELECT * from violation_2016_month WHERE  month BETWEEN 1 AND 3")
violation_frequency_season_1 <- summarize(groupBy(violation_2016_season_1, violation_2016_season_1$`Violation Code`),count = n(violation_2016_season_1$`Violation Code`))
collect(agg(violation_frequency_season_1, sum(violation_frequency_season_1$count)))

# Answer Sum(count)
#1    2671331

head(arrange(violation_frequency_season_1, desc(violation_frequency_season_1$count)),n=5)

#Answer 
 #1	21 	349644
#2             36 	341787
#3             38 	308999
#4             14 	218296
#5             37 	175613

# Violation code 21 is highest 


#Month 4-6
violation_2016_season_2 <- SparkR::sql("SELECT * from violation_2016_month WHERE  month BETWEEN 4 AND 6")
violation_frequency_season_2 <- summarize(groupBy(violation_2016_season_2, violation_2016_season_2$`Violation Code`),count = n(violation_2016_season_2$`Violation Code`))

collect(agg(violation_frequency_season_2, sum(violation_frequency_season_2$count)))

## Answers                 sum(count)
# 1   		 2425877		

head(arrange(violation_frequency_season_2, desc(violation_frequency_season_2$count)),n=5)

#Answers 
#Violation 	Code  count
#1	21 	348473
#2             36 	294015
#3             38 	254909
#4             14 	202729
#5             37 	163661


#Months 7 - 9
violation_2016_season_3 <- SparkR::sql("SELECT * from violation_2016_month WHERE  month BETWEEN 7 AND 9")
violation_frequency_season_3 <- summarize(groupBy(violation_2016_season_3, violation_2016_season_3$`Violation Code`),count = n(violation_2016_season_3$`Violation Code`))

collect(agg(violation_frequency_season_3, sum(violation_frequency_season_3$count)))

## Answer      2728663

head(arrange(violation_frequency_season_3, desc(violation_frequency_season_3$count)),n=5)
#1	21 	403720
#2             38 	305360
#3             14 	234943
#4             37 	185488
#5             36 	183744

#Months 10-12
violation_2016_season_4 <- SparkR::sql("SELECT * from violation_2016_month WHERE  month BETWEEN 10 AND 12")
violation_frequency_season_4 <- summarize(groupBy(violation_2016_season_4, violation_2016_season_4$`Violation Code`),count = n(violation_2016_season_4$`Violation Code`))

collect(agg(violation_frequency_season_4, sum(violation_frequency_season_4$count)))

## Answer  sum(count)
#1    	2801028

head(arrange(violation_frequency_season_4, desc(violation_frequency_season_4$count)),n=5)

#Violation Code  count
#1	36 	433966
#2             21 	429750
#3             38 	274428
#4             14 	219646
#5             37 	161848

#####################################################

code for 2017 data

library(SparkR)
sparkR.session(master='local')

parking2017 <- read.df("s3://data-science-421/Parking_Violations_Issued_-_Fiscal_Year_2017.csv",
                       source = "csv", inferSchema = "true", header = "true")

head(parking2017)

nrow(parking2017)

createOrReplaceTempView(parking2017, "Park_2017")
# 10803028 rows 
#Examine the data

#1) Find total number of tickets for each year.

unique_tickets <- SparkR::sql("SELECT count(distinct `Summons Number`) FROM Park_2017")

#10803028 unique tickets

# 2) Find out how many unique states the cars which got parking tickets came from.
# 67 unique registration states

unique_states <- SparkR::sql("SELECT count(distinct `Registration State`) FROM Park_2017")

head(unique_states)

Parking_2017_distinct<-dropDuplicates(parking2017)

nrow(Parking_2017_distinct)
#10803028 distinct 
createOrReplaceTempView(Parking_2017_distinct, "Park_2017_distinct")

## 3)Some parking tickets do not have address on them,which is cause for concern. Find out how many such tickets there are.

#Removing the duplicate rows

blank_address <- SparkR::sql("SELECT count(*) FROM Park_2017_distinct WHERE isNull(`House Number`) OR isNull(`Street Name`)")
##2289944 address not there 
head(blank_address)

#Aggregation tasks
#1)How often does each violation code occur? (frequency of violation codes - find the top 5)
viol_code_counts <- summarize(groupBy(Parking_2017_distinct, Parking_2017_distinct$`Violation Code`),
                              count = n(Parking_2017_distinct$`Violation Code`))
head(arrange(viol_code_counts, desc(viol_code_counts$count)))

####
#Violation Code   count
#1             21 1528588
#2             36 1400614
#3             38 1062304
#4             14  893498
#5             20  618593
#6             46  600012

#2)How often does each vehicle body type get a parking ticket? How about the vehicle make? (find the top 5 for both)
body_type_counts <- summarize(groupBy(Parking_2017_distinct, Parking_2017_distinct$`Vehicle Body Type`),
                              count = n(Parking_2017_distinct$`Vehicle Body Type`))
head(arrange(body_type_counts, desc(body_type_counts$count)))

#Vehicle Body Type   count
#1              SUBN 3719802
#2              4DSD 3082020
#3               VAN 1411970
#4              DELV  687330
#5               SDN  438191
#6              2DSD  274380

#3)A precinct is a police station that has a certain zone of the city under its command. Find the (5 highest) frequencies of:
#a)Violating Precincts (this is the precinct of the zone where the violation occurred)

viol_prec_counts <- summarize(groupBy(Parking_2017_distinct, Parking_2017_distinct$`Violation Precinct`),
                              count = n(Parking_2017_distinct$`Violation Precinct`))
head(arrange(viol_prec_counts, desc(viol_prec_counts$count)))

#tion Precinct   count
#1                  0 2072400
#2                 19  535671
#3                 14  352450
#4                  1  331810
#5                 18  306920
#6                114  296514

#b)Issuing Precincts (this is the precinct that issued the ticket)
issue_prec_counts <- summarize(groupBy(Parking_2017_distinct, Parking_2017_distinct$`Issuer Precinct`),
                               count = n(Parking_2017_distinct$`Issuer Precinct`))

head(arrange(issue_prec_counts, desc(issue_prec_counts$count)))

#1               0 2388479
#2              19  521513
#3              14  344977
#4               1  321170
#5              18  296553
#6             114  289950


#4)Find the violation code frequency across 3 precincts which have issued the most number of tickets - do these precinct zones have an exceptionally high frequency of certain violation codes? Are these codes common across precincts?

#top 3 are 19,18 & 14


Parking_2017_distinct_top_prec<- filter(Parking_2017_distinct, Parking_2017_distinct$`Issuer Precinct` == 19 | Parking_2017_distinct$`Issuer Precinct`==18 | Parking_2017_distinct$`Issuer Precinct`==14 )

freq <- summarize(groupBy(Parking_2017_distinct_top_prec, Parking_2017_distinct_top_prec$`Issuer Precinct`,Parking_2017_distinct_top_prec$`Violation Code`),
                    count = n(Parking_2017_distinct_top_prec$`Issuer Precinct`))



head(arrange(freq , desc(freq$count)),num=20)

#         Issuer precinct   ViolationCode count
#1               18             14      91485
#2               19             46      86390
#3               14             14       73837
#4               19             37      72437
#5               19             38      72344
#6               14             69      58026
#7               19             14      57563
#8               19             21      54700
#9               14             31      39857
#10              18             69      36744
#11              19             16      31353
#12              14             47      30540
#13              19             20      27352
#14              18             47      23727
#15              18             31      21514
#16              19             40      21513
#17              14             42      20663
#18              19             71      15107
#19              18             46      14868
#20              14             46      13435


#precinct 18 19 and 14 has highest number of count of violation 14 ,46 and 14

freq_a <- summarize(groupBy(Parking_2017_distinct_top_prec, Parking_2017_distinct_top_prec$`Violation Code`),
                     count = n(Parking_2017_distinct_top_prec$`Violation Code`))

head(arrange(freq_a , desc(freq_a$count)))
#Violation Code  count
#1             14 222885
#2             46 114693
#3             69  99315
#4             38  89863
#5             37  79829
#6             31  64665

#across three precincts, violation code '14 ' was issued most number of times

#do these precinct zones have an exceptionally high frequency of certain violation codes? Are these codes common across precincts?
#Exceptionally high frequency can be seen for violation codes 14 followed by 46 and 69.   However, only code '14' has shown consistently higher number across the top three issuer precincts.

#5)You�??d want to find out the properties of parking violations across different times of the day:
#The Violation Time field is specified in a strange format. 
#Find a way to make this into a time attribute that you can use to divide into groups.

##Substringing the hour part 

violation_2017_time <- withColumn(Parking_2017_distinct, "hour", substr(Parking_2017_distinct$`Violation Time`, 1, 2))
#substeing the clock am or pm 
violation_2017_time <- withColumn(violation_2017_time, "clock", substr(violation_2017_time$`Violation Time`, 6, 6))
#Converting to integer the hour 
violation_2017_time <- withColumn(violation_2017_time, "hour", cast(violation_2017_time$hour, "int"))

createOrReplaceTempView(violation_2017_time, "violation_2017_time")

#Find a way to deal with missing values, if any.

#Divide 24 hours into 6 equal discrete bins of time. The intervals you choose are at your discretion. For each of these groups, 
#find the 3 most commonly occurring violations
#00-03 AM
violation_2017_time_1 <- SparkR::sql("SELECT * from violation_2017_time WHERE  hour BETWEEN 00 AND 03 AND clock == 'A'")
violation_frequency_1 <- summarize(groupBy(violation_2017_time_1,violation_2017_time_1$`Violation Code`),count = n(violation_2017_time_1$`Violation Code`))
head(arrange(violation_frequency_1, desc(violation_frequency_1$count)),n=5)
# Violation Code count
#1             21 73160
#2             40 45960
#3             14 29311
#4             78 28848
#5             20 22744

#21 violation code occurs the max
##04-07AM
violation_2017_time_2 <- SparkR::sql("SELECT * from violation_2017_time WHERE  hour BETWEEN 04 AND 07 AND clock == 'A'")
violation_frequency_2 <- summarize(groupBy(violation_2017_time_2, violation_2017_time_2$`Violation Code`),count = n(violation_2017_time_2$`Violation Code`))
head(arrange(violation_frequency_2, desc(violation_frequency_2$count)),n=5)

#Violation Code  count
#1             14 141276
#2             21 119469
#3             40 112186
#4             20  84647
#5              7  44060

#4-7 violation code 14 occurs the most

#In hour 

#08-11 AM
violation_2017_time_3 <- SparkR::sql("SELECT * from violation_2017_time WHERE  hour BETWEEN 08 AND 11 AND clock == 'A'")
violation_frequency_3 <- summarize(groupBy(violation_2017_time_3, violation_2017_time_3$`Violation Code`),count = n(violation_2017_time_3$`Violation Code`))
head(arrange(violation_frequency_3, desc(violation_frequency_3$count)),n=5)
#Violation Code   count
#1             21 1182689
#2             36  751422
#3             38  346518
#4             14  274288
#5             46  213696
#21 vc in 8 - 11

#12-3 PM
violation_2017_time_4_a <- SparkR::sql("SELECT * from violation_2017_time WHERE hour == 12 AND clock == 'P'")
violation_2017_time_4_b <- SparkR::sql("SELECT * from violation_2017_time WHERE hour BETWEEN 01 AND 03 AND clock == 'P'")
violation_2017_time_4 <- unionAll(violation_2017_time_4_a, violation_2017_time_4_b)
violation_frequency_4 <- summarize(groupBy(violation_2017_time_4, violation_2017_time_4$`Violation Code`),count = n(violation_2017_time_4$`Violation Code`))

head(arrange(violation_frequency_4, desc(violation_frequency_4$count)),n=5)

#1             36 588395
#2             38 462756
#3             37 337074
#4             14 256302
#5             46 229325

#Violation code 36 very prominent between 12-3 pm
#04-07 PM
violation_2017_time_5 <- SparkR::sql("SELECT * from violation_2017_time WHERE  hour BETWEEN 04 AND 07 AND clock == 'P'")

violation_frequency_5 <- summarize(groupBy(violation_2017_time_5, violation_2017_time_5$`Violation Code`),count = n(violation_2017_time_5$`Violation Code`))

head(arrange(violation_frequency_5, desc(violation_frequency_5$count)),n=5)

#1             38 203232
#2             37 145784
#3             14 144749
#4              7 131768
#5             46  85551

# Violation code 38 is  highest

#08-11 PM
violation_2017_time_6 <- SparkR::sql("SELECT * from violation_2017_time WHERE  hour BETWEEN 08 AND 11 AND clock == 'P'")

violation_frequency_6 <- summarize(groupBy(violation_2017_time_6, violation_2017_time_6$`Violation Code`),count = n(violation_2017_time_6$`Violation Code`))

head(arrange(violation_frequency_6, desc(violation_frequency_6$count)),n=5)

#Violation Code count
#1              7 65593
#2             38 47029
#3             14 44779
#4             40 44542
#5             20 31085

#Violation code 7 is highest between 8 -11

#Now, try another direction. For the 3 most commonly occurring violation codes, find the most common times of day (in terms of the bins from the previous part)
#1              7  # late night
#1             38  # late evening
#1             36 # evening
#1             21 # noon
#1             14 # morning
#1             21 # early morning

#21,36,38 are the most common vcs 


#6)Let�??s try and find some seasonality in this data

#First, divide the year into some number of seasons, and find frequencies of tickets for each season.

#Then, find the 3 most common violations for each of these season
violation_2017_month <- withColumn(Parking_2017_distinct, "month", substr(Parking_2017_distinct$`Issue Date`, 1, 2))


violation_2017_month <- withColumn(violation_2017_month, "month", cast(violation_2017_month$month, "int"))


createOrReplaceTempView(violation_2017_month,"violation_2017_month")

#Month 1 -3
violation_2017_season_1 <- SparkR::sql("SELECT * from violation_2017_month WHERE  month BETWEEN 1 AND 3")


violation_frequency_season_1 <- summarize(groupBy(violation_2017_season_1, violation_2017_season_1$`Violation Code`),count = n(violation_2017_season_1$`Violation Code`))

collect(agg(violation_frequency_season_1, sum(violation_frequency_season_1$count)))

# Answer Sum(count)
#1    2671332

head(arrange(violation_frequency_season_1, desc(violation_frequency_season_1$count)),n=5)

#Answer 
#1             21 374202
#2             36 348240
#3             38 287017
#4             14 225515
#5             46 155138

#21 Violation code is highest 


#Month 4-6
violation_2017_season_2 <- SparkR::sql("SELECT * from violation_2017_month WHERE  month BETWEEN 4 AND 6")


violation_frequency_season_2 <- summarize(groupBy(violation_2017_season_2, violation_2017_season_2$`Violation Code`),count = n(violation_2017_season_2$`Violation Code`))

collect(agg(violation_frequency_season_2, sum(violation_frequency_season_2$count)))

## Answers                               sum(count)
# 1    3018840

head(arrange(violation_frequency_season_2, desc(violation_frequency_season_2$count)),n=5)

#Answers 
#Violation Code  count
#1             21 421184
#2             36 369902
#3             38 266909
#4             14 264057
#5             20 179474

#Months 7 - 9
violation_2017_season_3 <- SparkR::sql("SELECT * from violation_2017_month WHERE  month BETWEEN 7 AND 9")


violation_frequency_season_3 <- summarize(groupBy(violation_2017_season_3, violation_2017_season_3$`Violation Code`),count = n(violation_2017_season_3$`Violation Code`))

collect(agg(violation_frequency_season_3, sum(violation_frequency_season_3$count)))

## Answer 2463936

head(arrange(violation_frequency_season_3, desc(violation_frequency_season_3$count)),n=5)
#1             21 385774
#2             38 244985
#3             36 239879
#4             14 201661
#5             37 147755

#Months 10-12
violation_2017_season_4 <- SparkR::sql("SELECT * from violation_2017_month WHERE  month BETWEEN 10 AND 12")


violation_frequency_season_4 <- summarize(groupBy(violation_2017_season_4, violation_2017_season_4$`Violation Code`),count = n(violation_2017_season_4$`Violation Code`))

collect(agg(violation_frequency_season_4, sum(violation_frequency_season_4$count)))

## Answer  sum(count)
#1    2648920

head(arrange(violation_frequency_season_4, desc(violation_frequency_season_4$count)),n=5)

#Violation Code  count
#1             36 442593
#2             21 347428
#3             38 263393
#4             14 202265
#5             37 147634